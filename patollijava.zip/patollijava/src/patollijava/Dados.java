/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patollijava;

import java.util.Random;

/**
 *
 * @author yahir
 */
    public class Dados {
        public int lanzarDado() {
        Random random = new Random();
        int resultado = random.nextInt(6) + 1;
        System.out.println("Resultado del dado: " + resultado); // Depuración
        return resultado;
    }
    }
