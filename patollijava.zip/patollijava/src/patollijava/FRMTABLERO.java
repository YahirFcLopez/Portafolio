/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patollijava;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static Beta.FRMTABLERO.PORT;
import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.locks.*;
import javax.imageio.ImageIO;
import java.util.Base64;

/**
 *
 * @author yahir
 */
public class FRMTABLERO extends javax.swing.JFrame {
  //VARIABLES SERVIDOR 
     private static int turnoActual = 1;  // Jugador 1 comienza
    private static final Object lockTurno = new Object();  // Objeto para sincronizar el acceso a los turnos
    public static final int PORT = 12345; // Puerto para el servidor
    public ServerSocket serverSocket;
    public Socket clientSocket;
    private PrintWriter out;
     private static Set<PrintWriter> clientes = new HashSet<>(); // Para almacenar los clientes conectados
        private static int contadorJugadores = 1; // Empezamos con el jugador 1
//VARIABLES GENERALES PARA METODOS
public int currentFieldIndex3 = 27; // Posición inicial del tercer jugador
public int vidaJugador1 = 3, vidaJugador2 = 3;//VIDA DE JUGADORES
public int dineroJugador1 = 100, dineroJugador2 = 100;//DINERO DE JUGADORES
public int currentFieldIndex1 = 1; // Posición inicial del primer jugador
private int currentFieldIndex2 = 18; // Posición inicial del segundo jugador
private boolean jugador1Activo = true;
private boolean jugador2Activo = true;
 private static JFrame frame;
   public static JFrame getFrame() {
        return frame;  // Devuelve la instancia de la ventana
    }
    public FRMTABLERO() {
        initComponents();
        
        frame = this;  
           
    //HACER TRANSPARENTES LOS CAMPOS JTEXTFIELD
      for (int i = 1; i <= 69; i++) {
    try {
        JTextField jTextField = (JTextField) this.getClass().getDeclaredField("jTextField" + i).get(this);
        jTextField.setBackground(new java.awt.Color(0, 0, 0, 1));
    } catch (NoSuchFieldException | IllegalAccessException e) {
        e.printStackTrace();
    }
}

    }

       //CONFIGURACIONES Y FUNCIONES
    private void reiniciarJuego() {
    // Aquí puedes agregar la lógica para reiniciar el juego o cerrar la aplicación
    // Reinicia las variables de dinero y vidas, y vuelve a activar a los jugadores
    jugador1Activo = true;
    jugador2Activo = true;

  
    
    // Reiniciar valores
  
    this.dispose();// o inicializar todo
}
    private void verificarPerdida(int jugador) {
    switch (jugador) {
        case 1:
            if (dineroJugador1 <= 0 || vidaJugador1 <= 0) {
                jugador1Activo = false;
                JOptionPane.showMessageDialog(null, "Jugador 1 ha perdido.");
            }
            break;
        case 2:
            if (dineroJugador2 <= 0 || vidaJugador2 <= 0) {
                jugador2Activo = false;
                JOptionPane.showMessageDialog(null, "Jugador 2 ha perdido.");
            }
            break;
        default:
            System.out.println("Jugador no válido: " + jugador);
            break;
    }
}
    private void verificarGanador() {
    int jugadoresActivos = 0;
    String ganador = "";

    if (jugador1Activo) { jugadoresActivos++; ganador = "Jugador 1"; }
    if (jugador2Activo) { jugadoresActivos++; ganador = "Jugador 2"; }
    

    if (jugadoresActivos == 1) {
        JOptionPane.showMessageDialog(null, "¡El ganador es: " + ganador + "!");
        // Reiniciar o finalizar el juego según sea necesario
        reiniciarJuego();
    }
}
public void configurarJuego() {
    try {
        // Solicitar cantidad de dinero inicial
        String dineroInicialStr = JOptionPane.showInputDialog(null, "Ingrese la cantidad de dinero inicial para cada jugador:", "Configuración del Juego", JOptionPane.QUESTION_MESSAGE);
        int dineroInicial = Integer.parseInt(dineroInicialStr);

        // Solicitar cantidad de vidas inicial
        String vidasInicialStr = JOptionPane.showInputDialog(null, "Ingrese la cantidad de vidas para cada jugador:", "Configuración del Juego", JOptionPane.QUESTION_MESSAGE);
        int vidasInicial = Integer.parseInt(vidasInicialStr);

        // Asignar el dinero y las vidas a cada jugador
        dineroJugador1 = dineroInicial;
        dineroJugador2 = dineroInicial;
      
       
        
        vidaJugador1 = vidasInicial;
        vidaJugador2 = vidasInicial;
   
      

        JOptionPane.showMessageDialog(null, "Configuración completada:\nDinero inicial: $" + dineroInicial + "\nVidas: " + vidasInicial, "Configuración del Juego", JOptionPane.INFORMATION_MESSAGE);
        
        mostrarEstadoJugadores();
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Por favor, ingrese valores numéricos válidos.", "Error de Configuración", JOptionPane.ERROR_MESSAGE);
        configurarJuego(); // Reiniciar la configuración si hay un error
    }
}
public void verificarPenalizacion(int jugador, int posicionActual) {
    if (posicionActual == 5 || posicionActual == 6 || posicionActual == 66 || posicionActual == 67 ||
        posicionActual == 15 || posicionActual == 14 || posicionActual == 23 || posicionActual == 31|| posicionActual == 32|| posicionActual == 40|| posicionActual == 39
            || posicionActual == 49 || posicionActual == 56|| posicionActual == 57 || posicionActual == 48
            
            ) {
        
        int cantidadPerdida = 10; // Cantidad de dinero que pierde el jugador
        String jugadorNombre = "Jugador " + jugador;
        int dineroActual = 0;

        switch (jugador) {
            case 1:
                dineroJugador1 -= cantidadPerdida;
                dineroActual = dineroJugador1;
                break;
            case 2:
                dineroJugador2 -= cantidadPerdida;
                dineroActual = dineroJugador2;
                break;
           
       
            
        }

        // Mostrar mensaje con el dinero perdido y el dinero restante del jugador
        String mensaje = jugadorNombre + " ha caído en una casilla de penalización.\n" +
                         "Pierde $" + cantidadPerdida + ".\n" +
                         "Dinero restante: $" + dineroActual;
        JOptionPane.showMessageDialog(null, mensaje, "Penalización", JOptionPane.WARNING_MESSAGE);

        mostrarEstadoJugadores();
    }
}
public void mostrarEstadoJugadores() {
    String estado = "<html>Estado de los Jugadores:<br>" +
                    "Jugador 1: Vidas = " + vidaJugador1 + ", Dinero = $" + dineroJugador1 + "<br>" +
                    "Jugador 2: Vidas = " + vidaJugador2 + ", Dinero = $" + dineroJugador2 + "<br>" +
                   
                    "</html>";
    JLabel label = new JLabel(estado);
    JOptionPane.showMessageDialog(null, label, "Estado de los Jugadores", JOptionPane.INFORMATION_MESSAGE);
}
public void perderVidaYReiniciar(int jugador) {
    switch (jugador) {
        case 1:
            vidaJugador1--;
            currentFieldIndex1 = 1; // Posición inicial
            break;
        case 2:
            vidaJugador2--;
            currentFieldIndex2 = 18; // Posición inicial
            break;
  
            
    }
    mostrarEstadoJugadores();
}
public void verificarColision(int jugadorActual, int posicionActual) {
    if (posicionActual == currentFieldIndex1 && jugadorActual != 1) {
        perderVidaYReiniciar(1);
    }
    if (posicionActual == currentFieldIndex2 && jugadorActual != 2) {
        perderVidaYReiniciar(2);
    }
    
    
}
public void avanzarJugador(ActionEvent event) {
        // Envía la señal para avanzar el jugador al servidor
        if (out != null) {
            out.println("AVANZAR");
        }
        
        // Lógica para cambiar el estado del jugador en el JFrame
     random1();
    }
public void inicializarPosiciones() {
 JTextField field1 = getFieldByIndex(1); // Primero lo ubicamos en la casilla 1
    if (field1 != null) {
        field1.setText("  O");
        field1.setForeground(Color.RED);
    }

    // Posición inicial del jugador 2 en jTextField13
    JTextField field2 = getFieldByIndex(18); // Posición inicial en la casilla 13
    if (field2 != null) {
        field2.setText("  O");
        field2.setForeground(Color.BLUE);
    }

 



    // Actualizamos los índices iniciales
    currentFieldIndex1 = 1;  // Jugador 1
    currentFieldIndex2 = 18; // Jugador 2
   
} 
public void actualizarInterfaz(int jugador, int resultadoDado) {
    int error = 1;
    int VALORREAL = resultadoDado - error; // Ajustar el resultado según sea necesario
    jLabel1.setText("Resultado del dado:" + VALORREAL + " Turno player "+(jugador % 4 + 1));
    JOptionPane.showMessageDialog(null, "Resultado del dado: " + VALORREAL + "\nTurno player " + (jugador % 2 + 1));
}  

//METODOS DE MANEJO DE SERVIDOR
   // Método para manejar la comunicación con el cliente
public void handleClient(Socket clientSocket) {
    try (
        BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
    ) {
        synchronized (clientes) {
            clientes.add(out);  // Agregar el cliente a la lista de clientes conectados
        }
        System.out.println("Cliente conectado: " + clientSocket.getInetAddress());

        // Asignar un número de jugador al cliente
        int numeroJugador = obtenerNumeroJugador();
        System.out.println("Jugador asignado: " + numeroJugador);

        // Enviar el número de jugador al cliente
        out.println("JUGADOR:" + numeroJugador);

        // Crear un hilo para enviar capturas de pantalla periódicamente
        Thread envioCapturas = new Thread(() -> {
            while (clientSocket.isConnected()) {
                try {
                    enviarCapturaDePantalla();  // Enviar la captura de pantalla cada vez
                    Thread.sleep(1000);  // Intervalo de 1 segundo
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.out.println("Error al enviar la captura de pantalla: " + e.getMessage());
                    break;
                }
            }
        });
        envioCapturas.start();  // Iniciar el hilo para enviar imágenes

        // Manejar los mensajes recibidos
        String message;
        while ((message = in.readLine()) != null) {
            // Imprimir el mensaje recibido para depuración
            System.out.println("Mensaje recibido: " + message);

            // Verificar si el mensaje es una acción de avanzar
            if (message.startsWith("PLAYER")) {
                String[] partes = message.split(":");
                if (partes.length == 3 && "AVANZAR".equals(partes[2])) {
                    int jugador = Integer.parseInt(partes[1]);

                    // Realizar la acción de avanzar
                    handleAvanzar(jugador);
                }
            }
        }
    } catch (IOException e) {
        System.out.println("Error de comunicación con el cliente: " + e.getMessage());
    } finally {
        try {
            clientSocket.close();
        } catch (IOException e) {
            System.out.println("Error al cerrar el socket: " + e.getMessage());
        }
    }
}


 
// Método para manejar el avance de los jugadores
private void handleAvanzar(int jugador) {
    if (jugador != turnoActual) {
        JOptionPane.showMessageDialog(null, 
            "No es tu turno. Es el turno del jugador " + turnoActual, 
            "Turno incorrecto", 
            JOptionPane.WARNING_MESSAGE);
        return; // Salir si no es el turno del jugador actual
    }

    switch (jugador) {
        case 1:
            random1(); // Mover al jugador 1
            turnoActual = 2; // Cambiar al siguiente jugador
            break;
        case 2:
            random2(); // Mover al jugador 2
            turnoActual = 1; // Cambiar al siguiente jugador
            break;
      
        default:
            JOptionPane.showMessageDialog(null, 
                "Jugador no reconocido: " + jugador, 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
    }

    JOptionPane.showMessageDialog(null, 
        "Turno cambiado. Ahora es el turno del jugador " + turnoActual, 
        "Cambio de turno", 
        JOptionPane.INFORMATION_MESSAGE);
}

    // Método para obtener el número de jugador de acuerdo al turno
    private int obtenerNumeroJugador() {
        synchronized (lockTurno) {
            int jugador = turnoActual;
            return jugador;
        }
    }

     
   // Método para capturar la pantalla de FRMTABLERO y enviarla
    private void enviarCapturaDePantalla() {
        try {
            // Obtener las coordenadas y tamaño de la ventana (FRMTABLERO)
            Rectangle frameBounds = this.getBounds();

            // Crear un robot para capturar la pantalla
            Robot robot = new Robot();
            BufferedImage screenCapture = robot.createScreenCapture(frameBounds); // Captura solo el área de la ventana

            // Convertir la imagen capturada a base64
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(screenCapture, "PNG", baos);
            byte[] imageBytes = baos.toByteArray();
            String base64Image = Base64.getEncoder().encodeToString(imageBytes);

            // Enviar la imagen a todos los clientes
            synchronized (clientes) {
                for (PrintWriter out : clientes) {
                    out.println("IMAGE:" + base64Image);
                }
            }

        } catch (AWTException | IOException e) {
            System.out.println("Error al capturar la pantalla: " + e.getMessage());
        }
    }
    
    

    // Método para enviar la captura de pantalla periódicamente (cada 5 segundos)
    public void enviarCapturasPeriodicas() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                enviarCapturaDePantalla();
            }
        }, 0, 1000); // Enviar cada 5 segundos
    }

    // Método para iniciar el servidor
    public void startServer() {
        try {
            InetAddress ip = InetAddress.getLocalHost();
            jTextField69.setText("ip "+ip.getHostAddress());
             System.out.println("Dirección IPv4: " + ip.getHostAddress());
            serverSocket = new ServerSocket(PORT);
            System.out.println("Servidor iniciado en el puerto " + PORT);
JOptionPane.showMessageDialog(null, "Servidor iniciado en el puerto " + PORT);
            // Escuchar en un hilo separado
            new Thread(() -> {
                while (true) {
                    try {
                        Socket clientSocket = serverSocket.accept();
                        System.out.println("Cliente conectado: " + clientSocket.getInetAddress());

                        // Manejar la comunicación con el cliente
                       
                        handleClient(clientSocket);
                    } catch (IOException e) {
                        System.out.println("Error al aceptar la conexión: " + e.getMessage());
                    }
                }
            }).start();
        } catch (IOException e) {
            System.out.println("Error al iniciar el servidor: " + e.getMessage());
        }
    }
    // Método para detener el servidor y cerrar conexiones
public void stopServer() {
    try {
        if (serverSocket != null && !serverSocket.isClosed()) {
            serverSocket.close();  // Cerrar el ServerSocket para dejar de aceptar nuevas conexiones
            System.out.println("Servidor detenido.");
            JOptionPane.showMessageDialog(null, "Servidor detenido.");
        }
    } catch (IOException e) {
        System.out.println("Error al detener el servidor: " + e.getMessage());
    }
}
//METODOS RANDOM
public void random1() {
    Dados dados = new Dados(); // Crear instancia de Dados
    int resultadoDado = dados.lanzarDado(); // Lanzar el dado
    int nuevaPosicion = currentFieldIndex1;

    for (int i = 0; i < resultadoDado; i++) {
        cambiarEstadoJugadorPlayer1();
        nuevaPosicion++;
    }
    
    // Actualizar la posición del jugador 1
    currentFieldIndex1 = nuevaPosicion;

    // Actualizar la interfaz de usuario
 
    actualizarInterfaz(1, resultadoDado);
    verificarPenalizacion(1, nuevaPosicion);
    verificarColision(1, nuevaPosicion);
    verificarPerdida(1); // Verifica si el jugador 1 ha perdido
    verificarGanador(); // Verifica si hay un ganador
     System.out.println("Jugador 1 ha avanzado");
    jButton14.disable();
}
private void random2() {
    Dados dados = new Dados(); // Crear instancia de Dados
    int resultadoDado = dados.lanzarDado(); // Lanzar el dado
    int nuevaPosicion = currentFieldIndex2;

    for (int i = 0; i < resultadoDado; i++) {
        cambiarEstadoJugadorPlayer2();
        nuevaPosicion++;
    }

    // Actualizar la posición del jugador 2
    currentFieldIndex2 = nuevaPosicion;

    // Actualizar la interfaz de usuario
 
    actualizarInterfaz(2, resultadoDado);
    verificarPenalizacion(2, nuevaPosicion);
    verificarColision(2, nuevaPosicion);
     verificarPerdida(2); // Verifica si el jugador 1 ha perdido
    verificarGanador(); // Verifica si hay un ganador
   
}
//METODOS CAMBIO DE ESTADO
public void cambiarEstadoJugadorPlayer2() {
    // Cambia el texto de los JTextFields según el índice
    int previousFieldIndex = currentFieldIndex2 - 1;
    if (previousFieldIndex < 1) {
        previousFieldIndex = 68; // Si es menor que 1, vuelve al último JTextField
    }

    // Cambia el texto del JTextField anterior a "casilla X"
    JTextField previousField = getFieldByIndex(previousFieldIndex);
    if (previousField != null) {
        previousField.setText(" ");
        previousField.setForeground(Color.BLACK); // Cambia el color del texto a negro
    }

    // Cambia el texto del JTextField actual a "jugador 2" y cambia el color
    JTextField currentField = getFieldByIndex(currentFieldIndex2);
    if (currentField != null) {
        currentField.setText("  O");
        currentField.setForeground(Color.BLUE); // Cambia el color del texto a azul
    }

    // Incrementa el índice para la próxima llamada
    currentFieldIndex2++;

    // Reinicia el índice si supera el número de JTextFields
    if (currentFieldIndex2 > 68) {
        currentFieldIndex2 = 1;
    }
}
public void cambiarEstadoJugadorPlayer1() {
    // Cambia el texto de los JTextFields según el índice
    int previousFieldIndex = currentFieldIndex1 - 1;
    if (previousFieldIndex < 1) {
        previousFieldIndex = 68; // Si es menor que 1, vuelve al último JTextField (en este caso, 52)
    }

    // Cambia el texto del JTextField anterior a "casilla X"
    JTextField previousField = getFieldByIndex(previousFieldIndex);
    if (previousField != null) {
        previousField.setText(" ");
        previousField.setForeground(Color.BLACK); // Cambia el color del texto a negro
    }

    // Cambia el texto del JTextField actual a "jugador 1" y cambia el color
    JTextField currentField = getFieldByIndex(currentFieldIndex1);
    if (currentField != null) {
        currentField.setText("  O");
        currentField.setForeground(Color.red); // Cambia el color del texto a rojo
    }

    // Incrementa el índice para la próxima llamada
    currentFieldIndex1++;

    // Reinicia el índice si supera el número de JTextFields
    if (currentFieldIndex1 > 68) {
        currentFieldIndex1 = 1;
    }
} 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton13 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jTextField26 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jTextField30 = new javax.swing.JTextField();
        jTextField31 = new javax.swing.JTextField();
        jTextField32 = new javax.swing.JTextField();
        jTextField33 = new javax.swing.JTextField();
        jTextField34 = new javax.swing.JTextField();
        jTextField35 = new javax.swing.JTextField();
        jTextField36 = new javax.swing.JTextField();
        jTextField37 = new javax.swing.JTextField();
        jTextField38 = new javax.swing.JTextField();
        jTextField39 = new javax.swing.JTextField();
        jTextField40 = new javax.swing.JTextField();
        jTextField41 = new javax.swing.JTextField();
        jTextField42 = new javax.swing.JTextField();
        jTextField43 = new javax.swing.JTextField();
        jTextField44 = new javax.swing.JTextField();
        jTextField45 = new javax.swing.JTextField();
        jTextField46 = new javax.swing.JTextField();
        jTextField47 = new javax.swing.JTextField();
        jTextField48 = new javax.swing.JTextField();
        jTextField49 = new javax.swing.JTextField();
        jTextField50 = new javax.swing.JTextField();
        jTextField51 = new javax.swing.JTextField();
        jTextField52 = new javax.swing.JTextField();
        jTextField53 = new javax.swing.JTextField();
        jTextField54 = new javax.swing.JTextField();
        jTextField55 = new javax.swing.JTextField();
        jTextField56 = new javax.swing.JTextField();
        jTextField57 = new javax.swing.JTextField();
        jTextField58 = new javax.swing.JTextField();
        jTextField59 = new javax.swing.JTextField();
        jTextField60 = new javax.swing.JTextField();
        jTextField61 = new javax.swing.JTextField();
        jTextField62 = new javax.swing.JTextField();
        jTextField63 = new javax.swing.JTextField();
        jTextField64 = new javax.swing.JTextField();
        jTextField65 = new javax.swing.JTextField();
        jTextField66 = new javax.swing.JTextField();
        jTextField67 = new javax.swing.JTextField();
        jTextField68 = new javax.swing.JTextField();
        jTextField69 = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton15 = new javax.swing.JButton();

        jButton13.setBackground(new java.awt.Color(141, 126, 126));
        jButton13.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jButton13.setForeground(new java.awt.Color(102, 0, 0));
        jButton13.setText("JUGADOR 1");
        jButton13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0)));
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextField1.setEditable(false);
        jTextField1.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField1.setBorder(null);
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 30, 30));

        jTextField2.setEditable(false);
        jTextField2.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField2.setBorder(null);
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 230, 30, 30));

        jTextField3.setEditable(false);
        jTextField3.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField3.setBorder(null);
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 30, 30));

        jTextField4.setEditable(false);
        jTextField4.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField4.setBorder(null);
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 230, 30, 30));

        jTextField5.setEditable(false);
        jTextField5.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField5.setBorder(null);
        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 230, 30, 30));

        jTextField6.setEditable(false);
        jTextField6.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField6.setBorder(null);
        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 30, 30));

        jTextField7.setEditable(false);
        jTextField7.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField7.setBorder(null);
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 230, 30, 30));

        jTextField8.setEditable(false);
        jTextField8.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField8.setBorder(null);
        jTextField8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField8ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 230, 30, 30));

        jTextField9.setEditable(false);
        jTextField9.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField9.setBorder(null);
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 230, 30, 30));

        jTextField10.setEditable(false);
        jTextField10.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField10.setBorder(null);
        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 200, 30, 30));

        jTextField11.setEditable(false);
        jTextField11.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField11.setBorder(null);
        jTextField11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField11ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField11, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 170, 30, 30));

        jTextField12.setEditable(false);
        jTextField12.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField12.setBorder(null);
        jTextField12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField12ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, 30, 30));

        jTextField13.setEditable(false);
        jTextField13.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField13.setBorder(null);
        jTextField13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField13ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField13, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 30, 30));

        jTextField14.setEditable(false);
        jTextField14.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField14.setBorder(null);
        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField14, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 30, 30));

        jTextField15.setEditable(false);
        jTextField15.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField15.setBorder(null);
        jTextField15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField15ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField15, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 60, 30, 30));

        jTextField16.setEditable(false);
        jTextField16.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField16.setBorder(null);
        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField16, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 40, 30, 30));

        jTextField17.setEditable(false);
        jTextField17.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField17.setBorder(null);
        jTextField17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField17ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField17, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 30, 30));

        jTextField18.setEditable(false);
        jTextField18.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField18.setBorder(null);
        jTextField18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField18ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField18, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 30, 30));

        jTextField19.setEditable(false);
        jTextField19.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField19.setBorder(null);
        jTextField19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField19ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField19, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 40, 30, 20));

        jTextField20.setEditable(false);
        jTextField20.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField20.setBorder(null);
        jTextField20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField20ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField20, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 60, 30, 30));

        jTextField21.setEditable(false);
        jTextField21.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField21.setBorder(null);
        jTextField21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField21ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField21, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 30, 30));

        jTextField22.setEditable(false);
        jTextField22.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField22.setBorder(null);
        jTextField22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField22ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField22, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 110, 30, 30));

        jTextField23.setEditable(false);
        jTextField23.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField23.setBorder(null);
        jTextField23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField23ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField23, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 140, 30, 30));

        jTextField24.setEditable(false);
        jTextField24.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField24.setBorder(null);
        jTextField24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField24ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField24, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, 30, 30));

        jTextField25.setEditable(false);
        jTextField25.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField25.setBorder(null);
        jTextField25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField25ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField25, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 30, 30));

        jTextField26.setEditable(false);
        jTextField26.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField26.setBorder(null);
        jTextField26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField26ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField26, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 230, 30, 30));

        jTextField27.setEditable(false);
        jTextField27.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField27.setBorder(null);
        jTextField27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField27ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField27, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 230, 30, 30));

        jTextField28.setEditable(false);
        jTextField28.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField28.setBorder(null);
        jTextField28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField28ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField28, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 230, 30, 30));

        jTextField29.setEditable(false);
        jTextField29.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField29.setBorder(null);
        jTextField29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField29ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField29, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 230, 30, 30));

        jTextField30.setEditable(false);
        jTextField30.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField30.setBorder(null);
        jTextField30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField30ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField30, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 230, 30, 30));

        jTextField31.setEditable(false);
        jTextField31.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField31.setBorder(null);
        jTextField31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField31ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField31, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 230, 30, 30));

        jTextField32.setEditable(false);
        jTextField32.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField32.setBorder(null);
        jTextField32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField32ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField32, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 230, 30, 30));

        jTextField33.setEditable(false);
        jTextField33.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField33.setBorder(null);
        jTextField33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField33ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField33, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 220, 30, 30));

        jTextField34.setEditable(false);
        jTextField34.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField34.setBorder(null);
        jTextField34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField34ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField34, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 220, 30, 30));

        jTextField35.setEditable(false);
        jTextField35.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField35.setBorder(null);
        jTextField35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField35ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField35, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 250, 30, 30));

        jTextField36.setEditable(false);
        jTextField36.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField36.setBorder(null);
        jTextField36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField36ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField36, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 250, 30, 30));

        jTextField37.setEditable(false);
        jTextField37.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField37.setBorder(null);
        jTextField37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField37ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField37, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 260, 30, 30));

        jTextField38.setEditable(false);
        jTextField38.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField38.setBorder(null);
        jTextField38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField38ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField38, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 260, 30, 30));

        jTextField39.setEditable(false);
        jTextField39.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField39.setBorder(null);
        jTextField39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField39ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField39, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 260, 30, 30));

        jTextField40.setEditable(false);
        jTextField40.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField40.setBorder(null);
        jTextField40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField40ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField40, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 260, 30, 30));

        jTextField41.setEditable(false);
        jTextField41.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField41.setBorder(null);
        jTextField41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField41ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField41, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 260, 30, 30));

        jTextField42.setEditable(false);
        jTextField42.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField42.setBorder(null);
        jTextField42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField42ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField42, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, 30, 30));

        jTextField43.setEditable(false);
        jTextField43.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField43.setBorder(null);
        jTextField43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField43ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField43, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, 30, 30));

        jTextField44.setEditable(false);
        jTextField44.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField44.setBorder(null);
        jTextField44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField44ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField44, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 290, 30, 30));

        jTextField45.setEditable(false);
        jTextField45.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField45.setBorder(null);
        jTextField45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField45ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField45, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 320, 30, 30));

        jTextField46.setEditable(false);
        jTextField46.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField46.setBorder(null);
        jTextField46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField46ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField46, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 350, 30, 30));

        jTextField47.setEditable(false);
        jTextField47.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField47.setBorder(null);
        jTextField47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField47ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField47, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 380, 30, 30));

        jTextField48.setEditable(false);
        jTextField48.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField48.setBorder(null);
        jTextField48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField48ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField48, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 410, 30, 30));

        jTextField49.setEditable(false);
        jTextField49.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField49.setBorder(null);
        jTextField49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField49ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField49, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 440, 30, 30));

        jTextField50.setEditable(false);
        jTextField50.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField50.setBorder(null);
        jTextField50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField50ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField50, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 470, 30, 30));

        jTextField51.setEditable(false);
        jTextField51.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField51.setBorder(null);
        jTextField51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField51ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField51, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 500, 30, 30));

        jTextField52.setEditable(false);
        jTextField52.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField52.setBorder(null);
        jTextField52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField52ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField52, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 500, 30, 30));

        jTextField53.setEditable(false);
        jTextField53.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField53.setBorder(null);
        jTextField53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField53ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField53, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 470, 30, 30));

        jTextField54.setEditable(false);
        jTextField54.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField54.setBorder(null);
        jTextField54.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField54ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField54, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 440, 30, 30));

        jTextField55.setEditable(false);
        jTextField55.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField55.setBorder(null);
        jTextField55.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField55ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField55, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 410, 30, 30));

        jTextField56.setEditable(false);
        jTextField56.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField56.setBorder(null);
        jTextField56.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField56ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField56, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 380, 30, 30));

        jTextField57.setEditable(false);
        jTextField57.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField57.setBorder(null);
        jTextField57.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField57ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField57, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 350, 30, 30));

        jTextField58.setEditable(false);
        jTextField58.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField58.setBorder(null);
        jTextField58.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField58ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField58, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 320, 30, 30));

        jTextField59.setEditable(false);
        jTextField59.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField59.setBorder(null);
        jTextField59.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField59ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField59, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 290, 30, 30));

        jTextField60.setEditable(false);
        jTextField60.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField60.setBorder(null);
        jTextField60.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField60ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField60, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 30, 30));

        jTextField61.setEditable(false);
        jTextField61.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField61.setBorder(null);
        jTextField61.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField61ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField61, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 260, 30, 30));

        jTextField62.setEditable(false);
        jTextField62.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField62.setBorder(null);
        jTextField62.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField62ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField62, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, 30, 30));

        jTextField63.setEditable(false);
        jTextField63.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField63.setBorder(null);
        jTextField63.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField63ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField63, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 30, 30));

        jTextField64.setEditable(false);
        jTextField64.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField64.setBorder(null);
        jTextField64.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField64ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField64, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 260, 30, 30));

        jTextField65.setEditable(false);
        jTextField65.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField65.setBorder(null);
        jTextField65.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField65ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField65, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 260, 30, 30));

        jTextField66.setEditable(false);
        jTextField66.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField66.setBorder(null);
        jTextField66.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField66ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField66, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 30, 30));

        jTextField67.setEditable(false);
        jTextField67.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField67.setBorder(null);
        jTextField67.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField67ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField67, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 30, 30));

        jTextField68.setEditable(false);
        jTextField68.setFont(new java.awt.Font("Haettenschweiler", 0, 36)); // NOI18N
        jTextField68.setBorder(null);
        jTextField68.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField68ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField68, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 30, 30));

        jTextField69.setEditable(false);
        jPanel1.add(jTextField69, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 60, 190, 30));

        jButton9.setBackground(new java.awt.Color(51, 0, 0));
        jButton9.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Iniciar");
        jButton9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0)));
        jButton9.setBorderPainted(false);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 127, 30));

        jButton11.setBackground(new java.awt.Color(51, 0, 0));
        jButton11.setFont(new java.awt.Font("Serif", 1, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("SERVER");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 127, -1));

        jButton12.setBackground(new java.awt.Color(51, 0, 0));
        jButton12.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(255, 255, 255));
        jButton12.setText("Mostrar estado");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 190, -1));

        jButton10.setBackground(new java.awt.Color(141, 126, 126));
        jButton10.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jButton10.setForeground(new java.awt.Color(102, 0, 0));
        jButton10.setText("JUGADOR 2");
        jButton10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0)));
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 90, 152, 50));

        jButton6.setBackground(new java.awt.Color(51, 0, 0));
        jButton6.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(255, 255, 255));
        jButton6.setText("salir");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 490, 130, -1));

        jButton14.setBackground(new java.awt.Color(141, 126, 126));
        jButton14.setFont(new java.awt.Font("Haettenschweiler", 0, 24)); // NOI18N
        jButton14.setForeground(new java.awt.Color(102, 0, 0));
        jButton14.setText("JUGADOR 1");
        jButton14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0)));
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, 152, 50));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(102, 0, 0));
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 230, 50));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/patolli4.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 540));

        jButton15.setBackground(new java.awt.Color(51, 0, 0));
        jButton15.setFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jButton15.setForeground(new java.awt.Color(255, 255, 255));
        jButton15.setText("Iniciar");
        jButton15.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0), new java.awt.Color(102, 0, 0)));
        jButton15.setBorderPainted(false);
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 127, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField5ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jTextField11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField11ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField11ActionPerformed

    private void jTextField12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField12ActionPerformed

    private void jTextField13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField13ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jTextField15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField15ActionPerformed

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jTextField17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField17ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField17ActionPerformed

    private void jTextField18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField18ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField18ActionPerformed

    private void jTextField19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField19ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField19ActionPerformed

    private void jTextField20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField20ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField20ActionPerformed

    private void jTextField21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField21ActionPerformed

    private void jTextField22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField22ActionPerformed

    private void jTextField23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField23ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField23ActionPerformed

    private void jTextField24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField24ActionPerformed

    private void jTextField25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField25ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField25ActionPerformed

    private void jTextField26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField26ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField26ActionPerformed

    private void jTextField27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField27ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField27ActionPerformed

    private void jTextField28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField28ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField28ActionPerformed

    private void jTextField29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField29ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField29ActionPerformed

    private void jTextField30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField30ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField30ActionPerformed

    private void jTextField31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField31ActionPerformed

    private void jTextField32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField32ActionPerformed

    private void jTextField33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField33ActionPerformed

    private void jTextField34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField34ActionPerformed

    private void jTextField35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField35ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField35ActionPerformed

    private void jTextField36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField36ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField36ActionPerformed

    private void jTextField37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField37ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField37ActionPerformed

    private void jTextField38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField38ActionPerformed

    private void jTextField39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField39ActionPerformed

    private void jTextField40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField40ActionPerformed

    private void jTextField41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField41ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField41ActionPerformed

    private void jTextField42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField42ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField42ActionPerformed

    private void jTextField43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField43ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField43ActionPerformed

    private void jTextField44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField44ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField44ActionPerformed

    private void jTextField45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField45ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField45ActionPerformed

    private void jTextField46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField46ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField46ActionPerformed

    private void jTextField47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField47ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField47ActionPerformed

    private void jTextField48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField48ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField48ActionPerformed

    private void jTextField49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField49ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField49ActionPerformed

    private void jTextField50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField50ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField50ActionPerformed

    private void jTextField51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField51ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField51ActionPerformed

    private void jTextField52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField52ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField52ActionPerformed

    private void jTextField53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField53ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField53ActionPerformed

    private void jTextField54ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField54ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField54ActionPerformed

    private void jTextField55ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField55ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField55ActionPerformed

    private void jTextField56ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField56ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField56ActionPerformed

    private void jTextField57ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField57ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField57ActionPerformed

    private void jTextField58ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField58ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField58ActionPerformed

    private void jTextField59ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField59ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField59ActionPerformed

    private void jTextField60ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField60ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField60ActionPerformed

    private void jTextField61ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField61ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField61ActionPerformed

    private void jTextField62ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField62ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField62ActionPerformed

    private void jTextField63ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField63ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField63ActionPerformed

    private void jTextField64ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField64ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField64ActionPerformed

    private void jTextField65ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField65ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField65ActionPerformed

    private void jTextField66ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField66ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField66ActionPerformed

    private void jTextField67ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField67ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField67ActionPerformed

    private void jTextField68ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField68ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField68ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        startServer();
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
      mostrarEstadoJugadores();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
 handleAvanzar(2); // Llama a manejar el avance del Jugador 2
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        this.dispose();
        stopServer();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
  handleAvanzar(1); // Llama a manejar el avance del Jugador 1
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        inicializarPosiciones();
        configurarJuego();

    }//GEN-LAST:event_jButton9ActionPerformed
private JTextField getFieldByIndex(int index) {
    switch (index) {
        case 1: return jTextField1;
        case 2: return jTextField2;
        case 3: return jTextField3;
        case 4: return jTextField4;
        case 5: return jTextField5;
        case 6: return jTextField6;
        case 7: return jTextField7;
        case 8: return jTextField8;
        case 9: return jTextField9;
        case 10: return jTextField10;
        case 11: return jTextField11;
        case 12: return jTextField12;
        case 13: return jTextField13;
        case 14: return jTextField14;
        case 15: return jTextField15;
        case 16: return jTextField16;
        case 17: return jTextField17;
        case 18: return jTextField18;
        case 19: return jTextField19;
        case 20: return jTextField20;
        case 21: return jTextField21;
        case 22: return jTextField22;
        case 23: return jTextField23;
        case 24: return jTextField24;
        case 25: return jTextField25;
        case 26: return jTextField26;
        case 27: return jTextField27;
        case 28: return jTextField28;
        case 29: return jTextField29;
        case 30: return jTextField30;
        case 31: return jTextField31;
        case 32: return jTextField32;
        case 33: return jTextField33;
        case 34: return jTextField34;
        case 35: return jTextField35;
        case 36: return jTextField36;
        case 37: return jTextField37;
        case 38: return jTextField38;
        case 39: return jTextField39;
        case 40: return jTextField40;
        case 41: return jTextField41;
        case 42: return jTextField42;
        case 43: return jTextField43;
        case 44: return jTextField44;
        case 45: return jTextField45;
        case 46: return jTextField46;
        case 47: return jTextField47;
        case 48: return jTextField48;
        case 49: return jTextField49;
        case 50: return jTextField50;
        case 51: return jTextField51;
        case 52: return jTextField52;
        case 53: return jTextField53;
        case 54: return jTextField54;
        case 55: return jTextField55;
        case 56: return jTextField56;
        case 57: return jTextField57;
        case 58: return jTextField58;
        case 59: return jTextField59;
        case 60: return jTextField60;
        case 61: return jTextField61;
        case 62: return jTextField62;
        case 63: return jTextField63;
        case 64: return jTextField64;
        case 65: return jTextField65;
        case 66: return jTextField66;
        case 67: return jTextField67;
        case 68: return jTextField68;
        default: return null; // Retorna null si el índice no es válido
    }
}
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FRMTABLERO().setVisible(true);
            }
        });
    }

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField26;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField jTextField37;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField41;
    private javax.swing.JTextField jTextField42;
    private javax.swing.JTextField jTextField43;
    private javax.swing.JTextField jTextField44;
    private javax.swing.JTextField jTextField45;
    private javax.swing.JTextField jTextField46;
    private javax.swing.JTextField jTextField47;
    private javax.swing.JTextField jTextField48;
    private javax.swing.JTextField jTextField49;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField50;
    private javax.swing.JTextField jTextField51;
    private javax.swing.JTextField jTextField52;
    private javax.swing.JTextField jTextField53;
    private javax.swing.JTextField jTextField54;
    private javax.swing.JTextField jTextField55;
    private javax.swing.JTextField jTextField56;
    private javax.swing.JTextField jTextField57;
    private javax.swing.JTextField jTextField58;
    private javax.swing.JTextField jTextField59;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField60;
    private javax.swing.JTextField jTextField61;
    private javax.swing.JTextField jTextField62;
    private javax.swing.JTextField jTextField63;
    private javax.swing.JTextField jTextField64;
    private javax.swing.JTextField jTextField65;
    private javax.swing.JTextField jTextField66;
    private javax.swing.JTextField jTextField67;
    private javax.swing.JTextField jTextField68;
    private javax.swing.JTextField jTextField69;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables





}
