/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

import Beta.*;
import Entidades.*;

public class Jugador {
    private String nombre;
    private int apuesta;
    private int vidas;
    private int posicion;

    public Jugador(String nombre) {
        this.nombre = nombre;
        this.apuesta = 100; // Valor inicial de apuesta
        this.vidas = 3; // Valor inicial de vidas
        this.posicion = 0; // Posición inicial en el tablero
    }
 public void restarVida() {
        if (vidas > 0) {
            vidas--;
        }
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public int getApuesta() {
        return apuesta;
    }

    public void setApuesta(int apuesta) {
        this.apuesta = apuesta;
    }

    public int getVidas() {
        return vidas;
    }

    public void perderVida() {
        if (vidas > 0) {
            vidas--;
        }
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }
}
