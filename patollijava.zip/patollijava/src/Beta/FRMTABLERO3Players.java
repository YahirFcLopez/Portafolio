/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beta;


import java.awt.Color;
import java.awt.Color; // Asegúrate de importar el paquete para Color
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import javax.swing.JTextField;
    import Entidades.Jugador;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import patollijava.Dados;
import patollijava.FrmMenu;

/**
 *
 * @author yahir
 */
public class FRMTABLERO3Players extends javax.swing.JFrame {
  //VARIABLES SERVIDOR 
    public static final int PORT = 12345; // Puerto para el servidor
    public ServerSocket serverSocket;
    public Socket clientSocket;
    private PrintWriter out;
//VARIABLES GENERALES PARA METODOS
public int currentFieldIndex3 = 27; // Posición inicial del tercer jugador
public int vidaJugador1 = 3, vidaJugador2 = 3, vidaJugador3 = 3;//VIDA DE JUGADORES
public int dineroJugador1 = 100, dineroJugador2 = 100, dineroJugador3 = 100;//DINERO DE JUGADORES
public int currentFieldIndex1 = 1; // Posición inicial del primer jugador
private int currentFieldIndex2 = 13; // Posición inicial del segundo jugador
private boolean jugador1Activo = true;
private boolean jugador2Activo = true;
private boolean jugador3Activo = true;
private boolean jugador4Activo = true;


    /**
     * Creates new form FRMTABLERO
     */
    public FRMTABLERO3Players() {
        initComponents();
    }
  
  
   
    
//SERVIDOR
 public void handleClient(Socket clientSocket) {
    try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
        String message;
        while ((message = in.readLine()) != null) {
            // Suponemos que el mensaje tiene el formato "PLAYER:X:AVANZAR"
            String[] partes = message.split(":");
            if (partes.length == 3 && "AVANZAR".equals(partes[2])) {
                int jugador = Integer.parseInt(partes[1]); // Obtener el número del jugador

                switch (jugador) {
                    case 1:
                        random1(); // Mover al jugador 1
                        break;
                    case 2:
                        random2(); // Mover al jugador 2
                        break;
                    case 3:
                        random3(); // Mover al jugador 3
                        break;
                    
                    default:
                        System.out.println("Jugador no válido: " + jugador);
                        break;
                }
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    } finally {
        try {
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}   
 public void startServer(ActionEvent event) {
    try {
        serverSocket = new ServerSocket(PORT);
        System.out.println("Servidor iniciado en el puerto " + PORT);

        // Mostrar mensaje de confirmación
        JOptionPane.showMessageDialog(null, "Servidor iniciado en el puerto " + PORT);

        // Escuchar en un hilo separado
        new Thread(() -> {
            while (true) {
                try {
                    clientSocket = serverSocket.accept();
                    System.out.println("Cliente conectado: " + clientSocket.getInetAddress());

                    // Manejar la comunicación con el cliente
                    handleClient(clientSocket);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
  


//CONFIGURACIONES Y FUNCIONES
 private void verificarPerdida(int jugador) {
    switch (jugador) {
        case 1:
            if (dineroJugador1 <= 0 || vidaJugador1 <= 0) {
                jugador1Activo = false;
                JOptionPane.showMessageDialog(null, "Jugador 1 ha perdido.");
            }
            break;
        case 2:
            if (dineroJugador2 <= 0 || vidaJugador2 <= 0) {
                jugador2Activo = false;
                JOptionPane.showMessageDialog(null, "Jugador 2 ha perdido.");
            }
            break;
        case 3:
            if (dineroJugador3 <= 0 || vidaJugador3 <= 0) {
                jugador3Activo = false;
                JOptionPane.showMessageDialog(null, "Jugador 3 ha perdido.");
            }
        default:
            System.out.println("Jugador no válido: " + jugador);
            break;
    }
}

 private void reiniciarJuego() {
    // Aquí puedes agregar la lógica para reiniciar el juego o cerrar la aplicación
    // Reinicia las variables de dinero y vidas, y vuelve a activar a los jugadores
    jugador1Activo = true;
    jugador2Activo = true;
    jugador3Activo = true;
  
    
    // Reiniciar valores
    configurarJuego(); // o inicializar todo
}
    private void verificarGanador() {
    int jugadoresActivos = 0;
    String ganador = "";

    if (jugador1Activo) { jugadoresActivos++; ganador = "Jugador 1"; }
    if (jugador2Activo) { jugadoresActivos++; ganador = "Jugador 2"; }
    if (jugador3Activo) { jugadoresActivos++; ganador = "Jugador 3"; }
   

    if (jugadoresActivos == 1) {
        JOptionPane.showMessageDialog(null, "¡El ganador es: " + ganador + "!");
        // Reiniciar o finalizar el juego según sea necesario
        reiniciarJuego();
    }
}
  public void configurarJuego() {
    try {
        // Solicitar cantidad de dinero inicial
        String dineroInicialStr = JOptionPane.showInputDialog(null, "Ingrese la cantidad de dinero inicial para cada jugador:", "Configuración del Juego", JOptionPane.QUESTION_MESSAGE);
        int dineroInicial = Integer.parseInt(dineroInicialStr);

        // Solicitar cantidad de vidas inicial
        String vidasInicialStr = JOptionPane.showInputDialog(null, "Ingrese la cantidad de vidas para cada jugador:", "Configuración del Juego", JOptionPane.QUESTION_MESSAGE);
        int vidasInicial = Integer.parseInt(vidasInicialStr);

        // Asignar el dinero y las vidas a cada jugador
        dineroJugador1 = dineroInicial;
        dineroJugador2 = dineroInicial;
        dineroJugador3 = dineroInicial;
       
        
        vidaJugador1 = vidasInicial;
        vidaJugador2 = vidasInicial;
        vidaJugador3 = vidasInicial;
      

        JOptionPane.showMessageDialog(null, "Configuración completada:\nDinero inicial: $" + dineroInicial + "\nVidas: " + vidasInicial, "Configuración del Juego", JOptionPane.INFORMATION_MESSAGE);
        
        mostrarEstadoJugadores();
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(null, "Por favor, ingrese valores numéricos válidos.", "Error de Configuración", JOptionPane.ERROR_MESSAGE);
        configurarJuego(); // Reiniciar la configuración si hay un error
    }
}
public void verificarPenalizacion(int jugador, int posicionActual) {
    if (posicionActual == 3 || posicionActual == 51 || posicionActual == 11 || posicionActual == 16 ||
        posicionActual == 24 || posicionActual == 30 || posicionActual == 38 || posicionActual == 43) {
        
        int cantidadPerdida = 10; // Cantidad de dinero que pierde el jugador
        String jugadorNombre = "Jugador " + jugador;
        int dineroActual = 0;

        switch (jugador) {
            case 1:
                dineroJugador1 -= cantidadPerdida;
                dineroActual = dineroJugador1;
                break;
            case 2:
                dineroJugador2 -= cantidadPerdida;
                dineroActual = dineroJugador2;
                break;
            case 3:
                dineroJugador3 -= cantidadPerdida;
                dineroActual = dineroJugador3;
                break;
       
            
        }

        // Mostrar mensaje con el dinero perdido y el dinero restante del jugador
        String mensaje = jugadorNombre + " ha caído en una casilla de penalización.\n" +
                         "Pierde $" + cantidadPerdida + ".\n" +
                         "Dinero restante: $" + dineroActual;
        JOptionPane.showMessageDialog(null, mensaje, "Penalización", JOptionPane.WARNING_MESSAGE);

        mostrarEstadoJugadores();
    }
}
public void mostrarEstadoJugadores() {
    String estado = "<html>Estado de los Jugadores:<br>" +
                    "Jugador 1: Vidas = " + vidaJugador1 + ", Dinero = $" + dineroJugador1 + "<br>" +
                    "Jugador 2: Vidas = " + vidaJugador2 + ", Dinero = $" + dineroJugador2 + "<br>" +
                    "Jugador 3: Vidas = " + vidaJugador3 + ", Dinero = $" + dineroJugador3 + "<br>" +
                    "</html>";
    JLabel label = new JLabel(estado);
    JOptionPane.showMessageDialog(null, label, "Estado de los Jugadores", JOptionPane.INFORMATION_MESSAGE);
}
public void perderVidaYReiniciar(int jugador) {
    switch (jugador) {
        case 1:
            vidaJugador1--;
            currentFieldIndex1 = 1; // Posición inicial
            break;
        case 2:
            vidaJugador2--;
            currentFieldIndex2 = 13; // Posición inicial
            break;
        case 3:
            vidaJugador3--;
            currentFieldIndex3 = 25; // Posición inicial
            break;     
    }
    mostrarEstadoJugadores();
}
public void verificarColision(int jugadorActual, int posicionActual) {
    if (posicionActual == currentFieldIndex1 && jugadorActual != 1) {
        perderVidaYReiniciar(1);
    }
    if (posicionActual == currentFieldIndex2 && jugadorActual != 2) {
        perderVidaYReiniciar(2);
    }
    if (posicionActual == currentFieldIndex3 && jugadorActual != 3) {
        perderVidaYReiniciar(3);
    }
    
    
}
public void inicializarPosiciones() {
    // Posición inicial del jugador 1 en jTextField1
    JTextField field1 = getFieldByIndex(1); // Primero lo ubicamos en la casilla 1
    if (field1 != null) {
        field1.setText("Jugador 1");
        field1.setForeground(Color.RED);
    }

    // Posición inicial del jugador 2 en jTextField13
    JTextField field2 = getFieldByIndex(13); // Posición inicial en la casilla 13
    if (field2 != null) {
        field2.setText("Jugador 2");
        field2.setForeground(Color.BLUE);
    }

    // Posición inicial del jugador 3 en jTextField25
    JTextField field3 = getFieldByIndex(27); // Posición inicial en la casilla 25
    if (field3 != null) {
        field3.setText("Jugador 3");
        field3.setForeground(Color.GREEN); // Cambia el color si deseas
    }



    // Actualizamos los índices iniciales
    currentFieldIndex1 = 1;  // Jugador 1
    currentFieldIndex2 = 13; // Jugador 2
    currentFieldIndex3 = 25; // Jugador 3
   
}
public void actualizarInterfaz(int jugador, int resultadoDado) {
    int error = 1;
    int VALORREAL = resultadoDado - error; // Ajustar el resultado según sea necesario
    jLabel1.setText("Resultado del dado: " + VALORREAL + " - Turno player " + (jugador % 4 + 1));
    JOptionPane.showMessageDialog(null, "Resultado del dado: " + VALORREAL + "\nTurno player " + (jugador % 4 + 1));
}  

//METODOS RANDOM
public void random1() {
    Dados dados = new Dados(); // Crear instancia de Dados
    int resultadoDado = dados.lanzarDado(); // Lanzar el dado
    int nuevaPosicion = currentFieldIndex1;

    for (int i = 0; i < resultadoDado; i++) {
        cambiarEstadoJugadorPlayer1();
        nuevaPosicion++;
    }
    
    // Actualizar la posición del jugador 1
    currentFieldIndex1 = nuevaPosicion;

    // Actualizar la interfaz de usuario
    actualizarInterfaz(1, resultadoDado);
    verificarPenalizacion(1, nuevaPosicion);
    verificarColision(1, nuevaPosicion);
       verificarPerdida(1); // Verifica si el jugador 1 ha perdido
    verificarGanador(); // Verifica si hay un ganador
}
private void random2() {
    Dados dados = new Dados(); // Crear instancia de Dados
    int resultadoDado = dados.lanzarDado(); // Lanzar el dado
    int nuevaPosicion = currentFieldIndex2;

    for (int i = 0; i < resultadoDado; i++) {
        cambiarEstadoJugadorPlayer2();
        nuevaPosicion++;
    }

    // Actualizar la posición del jugador 2
    currentFieldIndex2 = nuevaPosicion;

    // Actualizar la interfaz de usuario
    actualizarInterfaz(2, resultadoDado);
    verificarPenalizacion(2, nuevaPosicion);
    verificarColision(2, nuevaPosicion);
     verificarPerdida(3); // Verifica si el jugador 1 ha perdido
    verificarGanador(); // Verifica si hay un ganador
}

private void random3() {
    Dados dados = new Dados(); // Crear instancia de Dados
    int resultadoDado = dados.lanzarDado(); // Lanzar el dado
    int nuevaPosicion = currentFieldIndex3;

    for (int i = 0; i < resultadoDado; i++) {
        cambiarEstadoJugadorPlayer3();
        nuevaPosicion++;
    }

    // Actualizar la posición del jugador 3
    currentFieldIndex3 = nuevaPosicion;

    // Actualizar la interfaz de usuario
    actualizarInterfaz(3, resultadoDado);
    verificarPenalizacion(3, nuevaPosicion);
    verificarColision(3, nuevaPosicion);
     verificarPerdida(3); // Verifica si el jugador 1 ha perdido
    verificarGanador(); // Verifica si hay un ganador
}
//METODOS CAMBIO DE ESTADO
public void cambiarEstadoJugadorPlayer2() {
    // Cambia el texto de los JTextFields según el índice
    int previousFieldIndex = currentFieldIndex2 - 1;
    if (previousFieldIndex < 1) {
        previousFieldIndex = 53; // Si es menor que 1, vuelve al último JTextField
    }

    // Cambia el texto del JTextField anterior a "casilla X"
    JTextField previousField = getFieldByIndex(previousFieldIndex);
    if (previousField != null) {
        previousField.setText("casilla " + previousFieldIndex);
        previousField.setForeground(Color.BLACK); // Cambia el color del texto a negro
    }

    // Cambia el texto del JTextField actual a "jugador 2" y cambia el color
    JTextField currentField = getFieldByIndex(currentFieldIndex2);
    if (currentField != null) {
        currentField.setText("jugador 2");
        currentField.setForeground(Color.BLUE); // Cambia el color del texto a azul
    }

    // Incrementa el índice para la próxima llamada
    currentFieldIndex2++;

    // Reinicia el índice si supera el número de JTextFields
    if (currentFieldIndex2 > 53) {
        currentFieldIndex2 = 1;
    }
}
public void cambiarEstadoJugadorPlayer1() {
    // Cambia el texto de los JTextFields según el índice
    int previousFieldIndex = currentFieldIndex1 - 1;
    if (previousFieldIndex < 1) {
        previousFieldIndex = 53; // Si es menor que 1, vuelve al último JTextField (en este caso, 52)
    }

    // Cambia el texto del JTextField anterior a "casilla X"
    JTextField previousField = getFieldByIndex(previousFieldIndex);
    if (previousField != null) {
        previousField.setText("casilla " + previousFieldIndex);
        previousField.setForeground(Color.BLACK); // Cambia el color del texto a negro
    }

    // Cambia el texto del JTextField actual a "jugador 1" y cambia el color
    JTextField currentField = getFieldByIndex(currentFieldIndex1);
    if (currentField != null) {
        currentField.setText("jugador 1");
        currentField.setForeground(Color.red); // Cambia el color del texto a rojo
    }

    // Incrementa el índice para la próxima llamada
    currentFieldIndex1++;

    // Reinicia el índice si supera el número de JTextFields
    if (currentFieldIndex1 > 53) {
        currentFieldIndex1 = 1;
    }
} 
public void cambiarEstadoJugadorPlayer3() {
    int previousFieldIndex = currentFieldIndex3 - 1;
    if (previousFieldIndex < 1) {
        previousFieldIndex = 53;
    }

    JTextField previousField = getFieldByIndex(previousFieldIndex);
    if (previousField != null) {
        previousField.setText("casilla " + previousFieldIndex);
        previousField.setForeground(Color.BLACK);
    }

    JTextField currentField = getFieldByIndex(currentFieldIndex3);
    if (currentField != null) {
        currentField.setText("jugador 3");
        currentField.setForeground(Color.GREEN); // Cambia el color a verde
    }

    currentFieldIndex3++;
    if (currentFieldIndex3 > 53) {
        currentFieldIndex3 = 1;
    }
}

// Método auxiliar para obtener el JTextField por índice
public JTextField getFieldByIndex(int index) {
    switch (index) {
        case 1: return jTextField1;
        case 2: return jTextField2;
        case 3: return jTextField3;
        case 4: return jTextField4;
        case 5: return jTextField5;
        case 6: return jTextField6;
        case 7: return jTextField7;
        case 8: return jTextField8;
        case 9: return jTextField9;
        case 10: return jTextField10;
        case 11: return jTextField11;
        case 12: return jTextField12;
        case 13: return jTextField13;
        case 14: return jTextField14;
        case 15: return jTextField15;
        case 16: return jTextField16;
        case 17: return jTextField17;
        case 18: return jTextField18;
        case 19: return jTextField19;
        case 20: return jTextField20;
        case 21: return jTextField21;
        case 22: return jTextField22;
        case 23: return jTextField23;
        case 24: return jTextField24;
        case 25: return jTextField25;
   
        case 27: return jTextField27;
        case 28: return jTextField28;
        case 29: return jTextField29;
        case 30: return jTextField30;
        case 31: return jTextField31;
        case 32: return jTextField32;
        case 33: return jTextField33;
        case 34: return jTextField34;
        case 35: return jTextField35;
        case 36: return jTextField36;
        case 37: return jTextField37;
        case 38: return jTextField38;
        case 39: return jTextField39;
        case 40: return jTextField40;
        case 41: return jTextField41;
        case 42: return jTextField42;
        case 43: return jTextField43;
        case 44: return jTextField44;
        case 45: return jTextField45;
        case 46: return jTextField46;
        case 47: return jTextField47;
        case 48: return jTextField48;
        case 49: return jTextField49;
        case 50: return jTextField50;
        case 51: return jTextField51;
        case 52: return jTextField52;
        case 53: return jTextField53;
        default: return null; // Retorna null si el índice no es válido
    }
}




    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField13 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jTextField18 = new javax.swing.JTextField();
        jTextField19 = new javax.swing.JTextField();
        jTextField20 = new javax.swing.JTextField();
        jTextField21 = new javax.swing.JTextField();
        jTextField22 = new javax.swing.JTextField();
        jTextField23 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jTextField25 = new javax.swing.JTextField();
        jTextField27 = new javax.swing.JTextField();
        jTextField28 = new javax.swing.JTextField();
        jTextField29 = new javax.swing.JTextField();
        jTextField30 = new javax.swing.JTextField();
        jTextField31 = new javax.swing.JTextField();
        jTextField32 = new javax.swing.JTextField();
        jTextField33 = new javax.swing.JTextField();
        jTextField34 = new javax.swing.JTextField();
        jTextField35 = new javax.swing.JTextField();
        jTextField36 = new javax.swing.JTextField();
        jTextField37 = new javax.swing.JTextField();
        jTextField38 = new javax.swing.JTextField();
        jTextField39 = new javax.swing.JTextField();
        jTextField40 = new javax.swing.JTextField();
        jTextField41 = new javax.swing.JTextField();
        jTextField42 = new javax.swing.JTextField();
        jTextField43 = new javax.swing.JTextField();
        jTextField44 = new javax.swing.JTextField();
        jTextField45 = new javax.swing.JTextField();
        jTextField46 = new javax.swing.JTextField();
        jTextField47 = new javax.swing.JTextField();
        jTextField48 = new javax.swing.JTextField();
        jTextField49 = new javax.swing.JTextField();
        jTextField50 = new javax.swing.JTextField();
        jTextField51 = new javax.swing.JTextField();
        jTextField52 = new javax.swing.JTextField();
        jTextField53 = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTextField1.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField1.setText("CASILLA 1");

        jButton1.setText("PLAYER 1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTextField2.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField2.setText("CASILLA 1");

        jTextField3.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField3.setText("CASILLA 1");

        jTextField4.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField4.setText("CASILLA 1");

        jTextField5.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField5.setText("CASILLA 1");

        jTextField6.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField6.setText("CASILLA 1");

        jButton2.setText("SERVER");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextField7.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField7.setText("CASILLA 1");

        jTextField8.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField8.setText("CASILLA 1");

        jTextField9.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField9.setText("CASILLA 1");
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });

        jTextField10.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField10.setText("CASILLA 1");

        jTextField11.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField11.setText("CASILLA 1");

        jTextField12.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField12.setText("CASILLA 1");

        jTextField13.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField13.setText("CASILLA 1");

        jTextField14.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField14.setText("CASILLA 1");

        jTextField15.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField15.setText("CASILLA 1");

        jTextField16.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField16.setText("CASILLA 1");

        jTextField17.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField17.setText("CASILLA 1");

        jTextField18.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField18.setText("CASILLA 1");

        jTextField19.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField19.setText("CASILLA 1");

        jTextField20.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField20.setText("CASILLA 1");

        jTextField21.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField21.setText("CASILLA 1");

        jTextField22.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField22.setText("CASILLA 1");

        jTextField23.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField23.setText("CASILLA 1");

        jTextField24.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField24.setText("CASILLA 1");

        jTextField25.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField25.setText("CASILLA 1");

        jTextField27.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField27.setText("CASILLA 1");

        jTextField28.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField28.setText("CASILLA 1");

        jTextField29.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField29.setText("CASILLA 1");

        jTextField30.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField30.setText("CASILLA 1");

        jTextField31.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField31.setText("CASILLA 1");
        jTextField31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField31ActionPerformed(evt);
            }
        });

        jTextField32.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField32.setText("CASILLA 1");
        jTextField32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField32ActionPerformed(evt);
            }
        });

        jTextField33.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField33.setText("CASILLA 1");
        jTextField33.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField33ActionPerformed(evt);
            }
        });

        jTextField34.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField34.setText("CASILLA 1");
        jTextField34.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField34ActionPerformed(evt);
            }
        });

        jTextField35.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField35.setText("CASILLA 1");
        jTextField35.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField35ActionPerformed(evt);
            }
        });

        jTextField36.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField36.setText("CASILLA 1");
        jTextField36.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField36ActionPerformed(evt);
            }
        });

        jTextField37.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField37.setText("CASILLA 1");
        jTextField37.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField37ActionPerformed(evt);
            }
        });

        jTextField38.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField38.setText("CASILLA 1");
        jTextField38.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField38ActionPerformed(evt);
            }
        });

        jTextField39.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField39.setText("CASILLA 1");
        jTextField39.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField39ActionPerformed(evt);
            }
        });

        jTextField40.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField40.setText("CASILLA 1");
        jTextField40.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField40ActionPerformed(evt);
            }
        });

        jTextField41.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField41.setText("CASILLA 1");
        jTextField41.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField41ActionPerformed(evt);
            }
        });

        jTextField42.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField42.setText("CASILLA 1");
        jTextField42.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField42ActionPerformed(evt);
            }
        });

        jTextField43.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField43.setText("CASILLA 1");
        jTextField43.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField43ActionPerformed(evt);
            }
        });

        jTextField44.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField44.setText("CASILLA 1");
        jTextField44.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField44ActionPerformed(evt);
            }
        });

        jTextField45.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField45.setText("CASILLA 1");
        jTextField45.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField45ActionPerformed(evt);
            }
        });

        jTextField46.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField46.setText("CASILLA 1");
        jTextField46.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField46ActionPerformed(evt);
            }
        });

        jTextField47.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField47.setText("CASILLA 1");
        jTextField47.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField47ActionPerformed(evt);
            }
        });

        jTextField48.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField48.setText("CASILLA 1");
        jTextField48.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField48ActionPerformed(evt);
            }
        });

        jTextField49.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField49.setText("CASILLA 1");
        jTextField49.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField49ActionPerformed(evt);
            }
        });

        jTextField50.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField50.setText("CASILLA 1");
        jTextField50.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField50ActionPerformed(evt);
            }
        });

        jTextField51.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField51.setText("CASILLA 1");
        jTextField51.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField51ActionPerformed(evt);
            }
        });

        jTextField52.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField52.setText("CASILLA 1");
        jTextField52.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField52ActionPerformed(evt);
            }
        });

        jTextField53.setFont(new java.awt.Font("Tahoma", 1, 5)); // NOI18N
        jTextField53.setText("CASILLA 1");
        jTextField53.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField53ActionPerformed(evt);
            }
        });

        jButton3.setText("salir");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N

        jButton4.setText("Player2 ");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("Start");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Player3");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton8.setText("Mostrar estado");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jTextField41, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTextField53, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField52, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField51, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField50, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(13, 13, 13))
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField44, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField45, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField46, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jTextField49, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField48, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField47, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(37, 37, 37))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(103, 103, 103)
                                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jTextField12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(101, 101, 101)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jTextField43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jTextField42, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField37, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField35, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(5, 5, 5)
                                .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jTextField40, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(49, 49, 49)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(92, 92, 92)
                                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(jTextField38, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jTextField39, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jTextField34, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField33, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextField32, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTextField36, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(92, 92, 92)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(60, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(195, 195, 195))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton8))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField14, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField15, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextField16, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField17, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(3, 3, 3)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField18, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField19, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField21, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField22, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField24, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField25, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField20, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField23, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField27, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField28, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField29, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jTextField30, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField31, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField32, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField33, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField34, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField47, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField48, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField49, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField50, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField51, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField52, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField53, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField35, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField46, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField36, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField45, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField37, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField44, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField38, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField43, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField39, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField42, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField40, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField41, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(47, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       // Llama al método random() para avanzarJugador el jugador actual
        random1(); // Este método lanzará el dado y moverá al jugador actual
    
    // Actualiza la interfaz o realiza otras acciones si es necesario
    // Por ejemplo, puedes mostrar el estado actual de los jugadores
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       startServer(evt);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField31ActionPerformed

    private void jTextField32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField32ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField32ActionPerformed

    private void jTextField33ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField33ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField33ActionPerformed

    private void jTextField34ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField34ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField34ActionPerformed

    private void jTextField35ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField35ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField35ActionPerformed

    private void jTextField36ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField36ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField36ActionPerformed

    private void jTextField37ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField37ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField37ActionPerformed

    private void jTextField38ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField38ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField38ActionPerformed

    private void jTextField39ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField39ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField39ActionPerformed

    private void jTextField40ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField40ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField40ActionPerformed

    private void jTextField41ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField41ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField41ActionPerformed

    private void jTextField42ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField42ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField42ActionPerformed

    private void jTextField43ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField43ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField43ActionPerformed

    private void jTextField44ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField44ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField44ActionPerformed

    private void jTextField45ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField45ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField45ActionPerformed

    private void jTextField46ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField46ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField46ActionPerformed

    private void jTextField47ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField47ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField47ActionPerformed

    private void jTextField48ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField48ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField48ActionPerformed

    private void jTextField49ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField49ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField49ActionPerformed

    private void jTextField50ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField50ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField50ActionPerformed

    private void jTextField51ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField51ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField51ActionPerformed

    private void jTextField52ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField52ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField52ActionPerformed

    private void jTextField53ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField53ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField53ActionPerformed

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
      this.dispose();
      FrmMenu menu = new FrmMenu();
      menu.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       random2();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
      inicializarPosiciones();
      configurarJuego();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        random3();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
 mostrarEstadoJugadores();      
    }//GEN-LAST:event_jButton8ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FRMTABLERO3Players.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FRMTABLERO3Players.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FRMTABLERO3Players.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FRMTABLERO3Players.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FRMTABLERO3Players().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField25;
    private javax.swing.JTextField jTextField27;
    private javax.swing.JTextField jTextField28;
    private javax.swing.JTextField jTextField29;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField30;
    private javax.swing.JTextField jTextField31;
    private javax.swing.JTextField jTextField32;
    private javax.swing.JTextField jTextField33;
    private javax.swing.JTextField jTextField34;
    private javax.swing.JTextField jTextField35;
    private javax.swing.JTextField jTextField36;
    private javax.swing.JTextField jTextField37;
    private javax.swing.JTextField jTextField38;
    private javax.swing.JTextField jTextField39;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField40;
    private javax.swing.JTextField jTextField41;
    private javax.swing.JTextField jTextField42;
    private javax.swing.JTextField jTextField43;
    private javax.swing.JTextField jTextField44;
    private javax.swing.JTextField jTextField45;
    private javax.swing.JTextField jTextField46;
    private javax.swing.JTextField jTextField47;
    private javax.swing.JTextField jTextField48;
    private javax.swing.JTextField jTextField49;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField50;
    private javax.swing.JTextField jTextField51;
    private javax.swing.JTextField jTextField52;
    private javax.swing.JTextField jTextField53;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
